# Halit Mineral Website

Website sederhana bertema halit (garam mineral) untuk portfolio GitHub.

## Fitur
- Landing page clean & modern
- Informasi tentang halit
- Form kontak sederhana

## Cara Menjalankan
Buka file `index.html` di browser.

## Deploy
Bisa menggunakan GitHub Pages.
