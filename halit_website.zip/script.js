document.querySelector("form").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("Pesan berhasil dikirim! Terima kasih.");
});
